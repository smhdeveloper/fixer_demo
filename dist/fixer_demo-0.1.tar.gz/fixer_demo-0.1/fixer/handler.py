def get_rates():
    print("hello rates")