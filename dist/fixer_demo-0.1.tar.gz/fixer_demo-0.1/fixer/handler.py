def get_rates():
    print("hello world , i love my wife zahra forever")