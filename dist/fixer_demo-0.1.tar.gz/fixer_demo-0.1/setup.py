from setuptools import setup

setup(name="fixer_demo",
      version=0.1,
      packages=["fixer"])