from setuptools import setup

setup(name="fixer_demo",
      version=0.3,
      url="https://github.com/smhdeveloper/fixer_demo",
      packages=["fixer"])