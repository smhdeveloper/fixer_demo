def get_rates():
    print("hello world , i love my wife zahra forever")
    
def sample():
    print("this is the sample")