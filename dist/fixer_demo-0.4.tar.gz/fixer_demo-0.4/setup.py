from setuptools import setup

setup(name="fixer_demo",
      version=0.4,
      url="https://github.com/smhdeveloper/fixer_demo",
      install_requires=['requests'],
      packages=["fixer"])